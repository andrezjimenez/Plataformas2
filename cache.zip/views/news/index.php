<a class="btn btn-success" href="<?php echo base_url('index.php/news/create') ?>"> Crear una Noticia</a>
<!-- <table class="table table-hover">

        <tr class="table-primary">
            <td>#</td>
            <td>Titulo</td>
            <td>texto</td>
            <td>Ver</td>
            <td>Editar</td>
            <td>Eliminar</td>
        </tr>
        <?php foreach ($news as $news_item): ?>
        <tr>
            <td>
            </td>
            <td>
                <?php echo $news_item['title'] ?>
            </td>
            <td>
                <?php echo $news_item['text'] ?>
            </td>
            <td>
                <p><a href="news/<?php echo $news_item['slug'] ?>">Ver artículo</a></p>
            </td>
            <td>
                <p><a class="btn btn-primary" href="<?php echo base_url('index.php/news/edit/'.$news_item['id']) ?>">Actualizar</a></p>
            </td>
            <td>
                <form method="DELETE" action="<?php echo base_url('index.php/news/delete/'.$news_item['slug']);?>">
                    <button type="submit" class="btn btn-danger"> Eliminar</button>
                </form>
                <!--<p><a href="news/<?php echo $news_item['slug'] ?>">Eliminar</a></p>-->
            </td>
        </tr>  
        <?php endforeach ?>

   </table> -->

