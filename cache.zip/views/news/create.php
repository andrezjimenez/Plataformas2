
  <!-- <div class="card-body">
        <h2 >Create a news item</h2>
       
        <label for="title"  class="col-sm-2 col-form-label">Título</label>
        <input type="input" name="title"  class="form-control"/><br />

        <label for="text"class="col-sm-2 col-form-label" >Texto</label>
        <textarea name="text" class="form-control" rows="5" id="comment"></textarea><br />

        <input type="submit" name="submit" value="Crear ítem de noticias" class="btn btn-success" />
        </form>
  </div> -->
<div class="card-body">
        <h2 >Crear Usuario</h2>
         <?php echo validation_errors(); ?> 
        <?php echo form_open('news/create') ?>
        <label  class="col-form-label" required>Nombre</label>
        <input type="input" name="nombre"  class="form-control"/>

        <label   class="col-form-label" required>Apellido</label>
        <input type="input" name="apellido"  class="form-control"/>

        <label   class="col-form-label" required>Correo Electronico</label>
        <input type="email" name="email"  class="form-control"/>

        <label  class="col-form-label" required>Usuario</label>
        <input type="text" name="usuario"  class="form-control"/>

        <label   class=" col-form-label" required>Contraseña</label>
        <input type="password" name="contraseña"  class="form-control"/>
        <label   class=" col-form-label" required>Confirme Contraseña</label>
        <input type="password" name="contraseña2"  class="form-control"/> <br>

        <!-- <label for="text"class="col-form-label" >Texto</label>
        <textarea name="text" class="form-control" rows="5" id="comment"></textarea><br /> -->

        <input type="submit" name="submit" value="Crear Usuario" class="btn btn-success" />
        </form>
  </div>
</div>

