<a class="btn btn-success" href="<?php echo base_url('index.php/news') ?>"> Volver al Inicio</a>
<?php
echo '<h2>'.$news_item[''].'</h2>';
// echo $news_item['text']; 