<div class="alert alert-success" role="alert">
  Creado Exitosamente!<br>
  <a class="btn btn-success" href="<?php echo base_url('index.php/news') ?>"> Volver al Inicio</a>
</div>