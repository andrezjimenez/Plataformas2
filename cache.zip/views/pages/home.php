
<!-- <a class="btn btn-primary" href="<?php echo base_url('index.php/news');?>"> Ingresar y ver las noticias</a> -->
<br>


<div class="container">
  <div class="row">
    <div class="col-sm">
     <h2> Bienvenido al sitema de afiliaciones virtual de la Funeraria Los Olivos</h2>
    </div>
  
    <div class="col-sm">
        <h3>Iniciar Sesion</h3>
        <br>
        <?php echo validation_errors(); ?> 
        <?php echo form_open('news/view') ?>

        

            <input type="text" placeholder="Usuario" name="usuario"   class="form-control" required>
            <br>
            <input type="password" placeholder="Contraseña"  class="form-control" name="usuario" required>
            <br>
            <input type="submit" class="btn btn-success">
            
        </form>
        <h6><a  href="<?php echo base_url('index.php/news/create');?>"> Registrese aqui</a></h6>
    </div>
  </div>
</div>