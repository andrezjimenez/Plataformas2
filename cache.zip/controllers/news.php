<?php
class News extends CI_Controller {
public function __construct()
    {
        parent::__construct();
        $this->load->model('news_model');
    }
public function index()
    {
        //$data['news'] = $this->news_model->get_news();
        $data['news'] = $this->news_model->get_news();
        $data['title'] = 'Archivo de noticias';
        $this->load->view('templates/header', $data);
        $this->load->view('news/index', $data);
        $this->load->view('templates/footer');
    }
public function view($usuario)
    {
        //$data['news'] = $this->news_model->get_news($slug);
        $data['news_item'] = $this->news_model->get_news($usuario);
        if (empty($data['news_item']))
        {
        show_404();
        }
        $data['title'] = $data['news_item']['title'];
        $this->load->view('templates/header', $data);
        $this->load->view('news/view', $data);
        $this->load->view('templates/footer');
    }

public function create()
    {
    $this->load->helper('form');
    $this->load->library('form_validation');
    $data['title'] = 'Crear Usuario';
     $this->form_validation->set_rules('nombre', 'Nombre', 'required');
     $this->form_validation->set_rules('apellido', 'Apellido', 'required');
     $this->form_validation->set_rules('email', 'Correo Electronico', 'required');
     $this->form_validation->set_rules('usuario', 'Usuario', 'required');
     $this->form_validation->set_rules('contraseña', 'Contraseña', 'required');

    if ($this->form_validation->run() === FALSE)
    {
        $this->load->view('templates/header', $data);
        $this->load->view('news/create');
        $this->load->view('templates/footer');
    }
    else
    {
        $this->news_model->set_news();
        $this->load->view('templates/header');
        $this->load->view('pages/home');
        $this->load->view('templates/footer');
       
    }
    }

public function delete($slug)
    {
        $item = $this->news_model->delete_item($slug);
        redirect(base_url('index.php/news'));
    }
public function edit($id)
   {
       $item = $this->news_model->find_item($id);
       $this->load->view('templates/header');
       $this->load->view('news/edit',array('item'=>$item));
       $this->load->view('templates/footer');
   }

   public function update($id)
   {
        $this->form_validation->set_rules('title', 'title', 'required');
        $this->form_validation->set_rules('text', 'text', 'required');

        if ($this->form_validation->run() == FALSE){
            $this->session->set_flashdata('errors', validation_errors());
            redirect(base_url('news/edit/'.$id));
        }else{ 
          $this->news_model->update_item($id);
          redirect(base_url('index.php/news'));
        }
   }   

}