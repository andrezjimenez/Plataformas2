<?php
class News_model extends CI_Model {
    public function __construct()
    {
        $this->load->database();
    }
    public function get_news($usuario = FALSE)
    {
        if ($usuario === FALSE)
        {
            $query = $this->db->get('news');
            return $query->result_array();
        }
        // $query = $this->db->get_where('usuarios', array('Usuario' => $usuario))->row();
        // return $query->row_array();
        return $this->db->get_where('usuarios', array('Usuario' => $usuario))->row();
    }
    public function set_news()
    {
        $this->load->helper('url');
        $slug = url_title($this->input->post('title'), 'dash', TRUE);
        $data = array(
        'Nombre_usuario' => $this->input->post('nombre'),
        'Apellido_usuario' => $this->input->post('apellido'),
        'Email' => $this->input->post('email'),
        'Usuario' => $this->input->post('usuario'),
        'Password' => $this->input->post('contraseña')

        );
        return $this->db->insert('usuarios', $data);
    }
    

    public function delete_item($slug)
    {
        return $this->db->delete('news', array('slug' => $slug));
    }

    public function find_item($id)
    {
        return $this->db->get_where('usuarios', array('Usuario' => $usuario))->row();
    }
    public function update_item($id) 
    {
        $data=array(
            'title' => $this->input->post('title'),
            'text'=> $this->input->post('text')
        );
        if($id==0){
            return $this->db->insert('news',$data);
        }else{
            $this->db->where('id',$id);
            return $this->db->update('news',$data);
        }        
    }
}
